# schedule-service — Мультиплатформенный сервис расписания (ПО-33)

Web-сайт + Telegram-бот, оба читают расписание из одной базы Supabase.
Адаптация ЛР №3 под выполнение **в одного** (роли "Разработчик 1" и "Разработчик 2"
из методички совмещены в одном человеке — вы делаете оба куска последовательно,
в одной ветке `main`).

## Чем отличается регламент от методички (работа в одного)

| В методичке (пара) | В одиночной версии |
|---|---|
| Разработчик 1 создаёт репозиторий, добавляет Разработчика 2 в Collaborators | Просто создаёте репозиторий на себя, Collaborators не нужны |
| Разработчик 2 работает в ветке `feature/frontend` | Всё делаете в `main` — веток для одного человека не нужно |
| Backend и Frontend пишутся параллельно двумя людьми | Пишете последовательно: сначала БД → бот → сайт (порядок ниже) |
| Issue "задание напарнику" | Не нужен |
| Pull Request + Merge | Не нужен — вместо PR делайте **осмысленные отдельные коммиты**, чтобы история всё равно показывала прогресс (см. ниже, зачёт всё равно требует ≥4 коммитов) |
| Отправка работы через Compare & pull request | Просто `git push` в `main` |

Итого зачётный минимум: **≥4 коммита в `main`**, рабочий сайт на Vercel, рабочий бот в Telegram,
оба берут данные из одной таблицы Supabase.

## Порядок работы

### Часть 1. Git
1. github.com → New repository → `schedule-service` (с галочкой Add a README).
2. GitHub Desktop → File → Clone Repository → склонировать себе.
3. Скопировать содержимое папок `database/`, `frontend/`, `telegram-bot/` из этого
   архива в склонированную папку репозитория.
4. Commit → "Initial project structure" → Push origin. **(коммит 1)**

### Часть 2. Supabase
1. supabase.com → создать проект.
2. Table Editor → создать таблицы **groups** и **schedule** — SQL уже готов
   в `database/schema.sql`, проще всего выполнить его целиком через
   **SQL Editor** в Supabase (там же сразу вставятся тестовые данные ПО-33).
3. Project Settings → API → скопировать `Project URL` и `anon public` ключ —
   они понадобятся и сайту, и боту.
4. Commit → "Add database schema with ПО-33 schedule" (сам SQL-файл в репозитории,
   не сами данные Supabase) **(коммит 2)**

### Часть 3. Telegram-бот (`telegram-bot/`)
1. Через `@BotFather` в Telegram создать бота, получить API-токен.
2. `cd telegram-bot && npm install`
3. Скопировать `.env.example` в `.env` и вписать туда:
   - `BOT_TOKEN` — токен от BotFather
   - `SUPABASE_URL`, `SUPABASE_ANON_KEY` — из Supabase
4. `node bot.js` — проверить, что бот отвечает на `/start`, `/today`, `/now`.
5. Commit → "Implement Telegram bot: /today and /now" **(коммит 3)**

### Часть 4. Сайт (`frontend/index.html`)
1. Открыть `frontend/index.html`, вписать в начало `<script>` свои
   `SUPABASE_URL` и `SUPABASE_ANON_KEY` (те же, что у бота).
2. Открыть файл в браузере (двойной клик) и проверить кнопки "Сегодня" и "Сейчас".
3. Commit → "Implement web frontend: today/now views" **(коммит 4)**
4. Задеплоить на vercel.com: New Project → импортировать репозиторий `schedule-service` →
   Root Directory указать `frontend` → Deploy.

### Часть 5. Финальная проверка (чек-лист методички)
- [ ] В репозитории ≥4 коммита с понятными сообщениями.
- [ ] Меняете название предмета прямо в Supabase Table Editor → сайт (после
      перезагрузки страницы) и бот (после следующей команды) показывают новое
      название — оба тянут данные из одной таблицы `schedule`.
- [ ] `/now` корректно определяет: идёт пара / перемена / пары на сегодня закончились.

## Структура репозитория

```
schedule-service/
├── README.md
├── database/
│   └── schema.sql          # таблицы groups, schedule + данные ПО-33
├── frontend/
│   └── index.html          # сайт (HTML/CSS/JS, Supabase JS client с CDN)
└── telegram-bot/
    ├── bot.js               # Node.js бот (node-telegram-bot-api + supabase-js)
    ├── package.json
    └── .env.example
```
